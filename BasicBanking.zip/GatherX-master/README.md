## GatherX
Social Media Connector 
This App is made to complete Task #5 of Graduate Rotational Internship Program(GRIP) of The Sparks Foundation i.e Social Media Integration in an Android App

In this App, User can login by Social Media like Facebook and Twitter, Then his/her basic info like Name, Profile photo and Email are displayed on the second page.

# Preview

<img src="app/src/test/java/com/trendster/gatherx/Splash_page.jpg" width="300" >
<img src="app/src/test/java/com/trendster/gatherx/Login_screen.jpg" width="300" >
<img src="app/src/test/java/com/trendster/gatherx/Profile_screen.jpg" width="300" >
